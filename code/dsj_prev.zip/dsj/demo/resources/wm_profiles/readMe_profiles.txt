As of WindowsMedia Format SDK 9, Microsoft are no longer adding WM profiles to the list of predefined "system profiles" (which are the ones available on the WM Encoder filter's property page). Instead one configures the encoder via customized profiles.

The supplied profiles are just to be seen as simple examples.

If you have Windows Media Encoder installed you will find a tool to create profiles at:

Start->Programs->WindowsMedia->Utilities->Windows Media Profile Editor

.prx files are basically xml files and can be created in any other way.
